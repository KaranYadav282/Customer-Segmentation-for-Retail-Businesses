"""
Retail Customer Segmentation using RFM Analysis and K-Means Clustering
-----------------------------------------------------------------------
Command-line version of the Streamlit app (app.py).

Usage:
    python retail_customer_segmentation.py
    python retail_customer_segmentation.py --input data/online_retail.csv --output outputs

Steps:
    1. Load and clean transaction data
    2. Build customer-level RFM features
    3. Log-transform + standardise RFM
    4. Evaluate K = 2..10 (elbow + silhouette) and pick best K
    5. Fit final K-Means model, name segments, suggest marketing strategies
    6. Save charts and CSV reports
    7. Demonstrate prediction for a new customer
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

sns.set_theme(style="whitegrid")
REQUIRED_COLUMNS = ["customerid", "invoiceno", "invoicedate", "quantity", "unitprice"]


def clean_data(df):
    df = df.copy()
    df.columns = df.columns.astype(str).str.strip().str.lower().str.replace(" ", "_", regex=False)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))

    df = df.dropna(subset=["customerid"]).copy()
    df["customerid"] = df["customerid"].astype(str).str.strip()
    df["invoiceno"] = df["invoiceno"].astype(str).str.strip()
    df["invoicedate"] = pd.to_datetime(df["invoicedate"], errors="coerce")
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
    df["unitprice"] = pd.to_numeric(df["unitprice"], errors="coerce")
    df = df.dropna(subset=["invoicedate", "quantity", "unitprice"]).drop_duplicates()
    df = df[df["unitprice"] > 0]
    df = df[df["quantity"] > 0].copy()          # remove returns / cancellations
    df["total_amount"] = df["quantity"] * df["unitprice"]
    df = df[np.isfinite(df["total_amount"]) & (df["total_amount"] > 0)].copy()
    if df.empty:
        raise ValueError("No valid transactions remain after cleaning.")
    return df


def build_rfm(df):
    reference_date = df["invoicedate"].max() + pd.Timedelta(days=1)
    rfm = (
        df.groupby("customerid")
        .agg(
            Recency=("invoicedate", lambda x: (reference_date - x.max()).days),
            Frequency=("invoiceno", "nunique"),
            Monetary=("total_amount", "sum"),
        )
        .reset_index()
    )
    rfm = rfm[(rfm["Recency"] >= 0) & (rfm["Frequency"] > 0) & (rfm["Monetary"] > 0)].copy()
    return rfm, reference_date


def classify_segment(row):
    r, f, m = row["Recency_Ratio"], row["Frequency_Ratio"], row["Monetary_Ratio"]
    if r <= 0.75 and f >= 1.20 and m >= 1.20:
        return "High Value Customers"
    elif r <= 0.85 and f >= 1.20:
        return "Loyal Customers"
    elif r >= 1.30 and m >= 1.20:
        return "At Risk High-Value Customers"
    elif r <= 0.85 and f < 0.80:
        return "New or Occasional Customers"
    elif r >= 1.30 and f < 0.80 and m < 0.80:
        return "Low Engagement Customers"
    elif f >= 1.20 and m < 0.80:
        return "Frequent Low-Spend Customers"
    elif r >= 1.50:
        return "Inactive Customers"
    return "Regular Customers"


STRATEGIES = {
    "High Value": "Use loyalty rewards, personalized recommendations, exclusive offers and early access to products.",
    "Loyal": "Use loyalty points, repeat-purchase rewards, cross-selling and personalized recommendations.",
    "At Risk High-Value": "Use re-engagement campaigns, personalized offers and reminders based on previous purchases.",
    "New or Occasional": "Use introductory offers, product recommendations and incentives to encourage repeat purchases.",
    "Low Engagement": "Use targeted promotions and low-cost re-engagement campaigns to increase customer activity.",
    "Frequent Low-Spend": "Use product bundles, cross-selling and volume-based offers to increase average spending.",
    "Inactive": "Use win-back campaigns, reminders and personalized offers to encourage another purchase.",
}


def get_strategy(segment):
    for key in ["High Value", "Loyal", "At Risk High-Value", "New or Occasional",
                "Low Engagement", "Frequent Low-Spend", "Inactive"]:
        if key in segment:
            return STRATEGIES[key]
    return "Use regular promotional campaigns, personalized recommendations and loyalty incentives."


def train_model(rfm):
    rfm_log = np.log1p(rfm[["Recency", "Frequency", "Monetary"]])
    scaler = StandardScaler()
    X = scaler.fit_transform(rfm_log)

    ks = list(range(2, min(10, len(rfm) - 1) + 1))
    inertia, sil = [], []
    for k in ks:
        km = KMeans(n_clusters=k, random_state=42, n_init=20)
        labels = km.fit_predict(X)
        inertia.append(km.inertia_)
        sil.append(silhouette_score(X, labels))

    best_k = ks[int(np.argmax(sil))]
    kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=20)
    rfm = rfm.copy()
    rfm["Cluster"] = kmeans.fit_predict(X)

    prof = (
        rfm.groupby("Cluster")
        .agg(Customers=("customerid", "count"), Avg_Recency=("Recency", "mean"),
             Avg_Frequency=("Frequency", "mean"), Avg_Monetary=("Monetary", "mean"),
             Total_Revenue=("Monetary", "sum"))
        .reset_index()
    )
    prof[["Avg_Recency", "Avg_Frequency", "Avg_Monetary", "Total_Revenue"]] = \
        prof[["Avg_Recency", "Avg_Frequency", "Avg_Monetary", "Total_Revenue"]].round(2)
    prof["Recency_Ratio"] = prof["Avg_Recency"] / rfm["Recency"].mean()
    prof["Frequency_Ratio"] = prof["Avg_Frequency"] / rfm["Frequency"].mean()
    prof["Monetary_Ratio"] = prof["Avg_Monetary"] / rfm["Monetary"].mean()
    prof["Segment"] = prof.apply(classify_segment, axis=1)

    counts = prof["Segment"].value_counts()
    for seg in counts[counts > 1].index:
        m = prof["Segment"] == seg
        prof.loc[m, "Segment"] = prof.loc[m, "Segment"] + " (Cluster " + prof.loc[m, "Cluster"].astype(str) + ")"

    name_map = dict(zip(prof["Cluster"], prof["Segment"]))
    rfm["Segment"] = rfm["Cluster"].map(name_map)
    prof["Marketing_Strategy"] = prof["Segment"].apply(get_strategy)
    final = prof[["Cluster", "Segment", "Customers", "Avg_Recency", "Avg_Frequency",
                  "Avg_Monetary", "Total_Revenue", "Marketing_Strategy"]]
    return dict(customer_data=rfm, final_profile=final, scaler=scaler, kmeans=kmeans,
                name_map=name_map, X=X, ks=ks, inertia=inertia, sil=sil,
                best_k=best_k, best_sil=max(sil))


def predict_segment(recency, frequency, monetary, art):
    v = np.log1p(pd.DataFrame([[recency, frequency, monetary]], columns=["Recency", "Frequency", "Monetary"], dtype=float))
    c = int(art["kmeans"].predict(art["scaler"].transform(v))[0])
    return art["name_map"][c]


def save_charts(df, rfm, art, out):
    out = Path(out)
    # 1. Monthly revenue
    monthly = df.set_index("invoicedate")["total_amount"].resample("MS").sum()
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(monthly.index.strftime("%b"), monthly.values, color="#4C72B0")
    ax.set_title("Monthly Revenue (2025)"); ax.set_xlabel("Month"); ax.set_ylabel("Revenue")
    fig.tight_layout(); fig.savefig(out / "01_monthly_revenue.png", dpi=150); plt.close(fig)

    # 2. RFM distributions
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    for ax, col, colr in zip(axes, ["Recency", "Frequency", "Monetary"], ["#55A868", "#C44E52", "#4C72B0"]):
        sns.histplot(rfm[col], bins=40, kde=True, ax=ax, color=colr)
        ax.set_title(f"Distribution of {col}")
    fig.tight_layout(); fig.savefig(out / "02_rfm_distributions.png", dpi=150); plt.close(fig)

    # 3. Monetary distribution
    fig, ax = plt.subplots(figsize=(9, 5))
    sns.histplot(rfm["Monetary"], bins=40, kde=True, ax=ax)
    ax.set_title("Distribution of Customer Monetary Value")
    ax.set_xlabel("Monetary"); ax.set_ylabel("Number of Customers")
    fig.tight_layout(); fig.savefig(out / "03_monetary_distribution.png", dpi=150); plt.close(fig)

    # 4. Correlation heatmap
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(rfm[["Recency", "Frequency", "Monetary"]].corr(), annot=True, cmap="coolwarm", fmt=".2f", ax=ax)
    ax.set_title("Correlation between RFM Features")
    fig.tight_layout(); fig.savefig(out / "04_rfm_correlation.png", dpi=150); plt.close(fig)

    # 5. Elbow
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(art["ks"], art["inertia"], marker="o")
    ax.set_title("Elbow Method"); ax.set_xlabel("Number of Clusters (K)")
    ax.set_ylabel("Within-Cluster Sum of Squares"); ax.set_xticks(art["ks"])
    fig.tight_layout(); fig.savefig(out / "05_elbow_method.png", dpi=150); plt.close(fig)

    # 6. Silhouette
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(art["ks"], art["sil"], marker="o", color="#C44E52")
    ax.set_title("Silhouette Scores"); ax.set_xlabel("Number of Clusters (K)")
    ax.set_ylabel("Silhouette Score"); ax.set_xticks(art["ks"])
    fig.tight_layout(); fig.savefig(out / "06_silhouette_scores.png", dpi=150); plt.close(fig)

    # 7. Segment scatter
    cd = art["customer_data"]
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.scatterplot(data=cd, x="Frequency", y="Monetary", hue="Segment", s=50, ax=ax)
    ax.set_title("Customer Segmentation by Frequency and Monetary Value")
    ax.set_xlabel("Purchase Frequency"); ax.set_ylabel("Total Spending")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.tight_layout(); fig.savefig(out / "07_segments_scatter.png", dpi=150); plt.close(fig)

    # 8. PCA
    pca = PCA(n_components=2)
    p = pca.fit_transform(art["X"])
    pdf = pd.DataFrame(p, columns=["PCA1", "PCA2"]); pdf["Segment"] = cd["Segment"].values
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.scatterplot(data=pdf, x="PCA1", y="PCA2", hue="Segment", s=50, ax=ax)
    ax.set_title("Customer Segments Visualized Using PCA")
    ax.set_xlabel("Principal Component 1"); ax.set_ylabel("Principal Component 2")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.tight_layout(); fig.savefig(out / "08_pca_segments.png", dpi=150); plt.close(fig)

    # 9. Segment sizes + revenue share
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    cd["Segment"].value_counts().plot(kind="bar", ax=axes[0], color="#4C72B0")
    axes[0].set_title("Customers in Each Segment"); axes[0].set_xlabel("Segment"); axes[0].set_ylabel("Customers")
    axes[0].tick_params(axis="x", rotation=20)
    cd.groupby("Segment")["Monetary"].sum().plot(kind="pie", ax=axes[1], autopct="%1.1f%%", ylabel="")
    axes[1].set_title("Revenue Share by Segment")
    fig.tight_layout(); fig.savefig(out / "09_segment_size_revenue.png", dpi=150); plt.close(fig)

    # 10. Segment RFM comparison
    prof = art["final_profile"].set_index("Segment")[["Avg_Recency", "Avg_Frequency", "Avg_Monetary"]]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.5))
    for ax, col in zip(axes, prof.columns):
        prof[col].plot(kind="bar", ax=ax, color=["#55A868", "#C44E52", "#8172B2", "#CCB974"][:len(prof)])
        ax.set_title(col.replace("_", " ")); ax.set_xlabel(""); ax.tick_params(axis="x", rotation=20)
    fig.tight_layout(); fig.savefig(out / "10_segment_rfm_comparison.png", dpi=150); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/online_retail.csv")
    ap.add_argument("--output", default="outputs")
    ap.add_argument("--charts", default="screenshots")
    args = ap.parse_args()

    Path(args.output).mkdir(exist_ok=True, parents=True)
    Path(args.charts).mkdir(exist_ok=True, parents=True)

    raw = pd.read_csv(args.input)
    df = clean_data(raw)
    rfm, ref = build_rfm(df)
    art = train_model(rfm)

    print(f"Raw rows            : {len(raw):,}")
    print(f"Valid transactions  : {len(df):,}")
    print(f"Unique customers    : {rfm['customerid'].nunique():,}")
    print(f"Total revenue       : {df['total_amount'].sum():,.2f}")
    print(f"Reference date      : {ref.date()}")
    print(f"Best K              : {art['best_k']}  (silhouette = {art['best_sil']:.4f})")
    print(art["final_profile"].drop(columns="Marketing_Strategy").to_string(index=False))

    art["customer_data"].to_csv(Path(args.output) / "customer_segments.csv", index=False)
    art["final_profile"].to_csv(Path(args.output) / "segment_profile.csv", index=False)
    with pd.ExcelWriter(Path(args.output) / "customer_segmentation_report.xlsx") as w:
        art["customer_data"].to_excel(w, sheet_name="Customer Segments", index=False)
        art["final_profile"].to_excel(w, sheet_name="Segment Profile", index=False)

    save_charts(df, rfm, art, args.charts)

    print("\nExample prediction (Recency=20, Frequency=15, Monetary=2500):",
          predict_segment(20, 15, 2500, art))
    print("Example prediction (Recency=200, Frequency=1, Monetary=300):",
          predict_segment(200, 1, 300, art))


if __name__ == "__main__":
    main()
