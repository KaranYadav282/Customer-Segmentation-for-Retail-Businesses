import io
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

st.set_page_config(
    page_title="Retail Customer Segmentation",
    page_icon="📊",
    layout="wide"
)

sns.set_theme(style="whitegrid")

REQUIRED_COLUMNS = ["customerid", "invoiceno", "invoicedate", "quantity", "unitprice"]


def standardize_columns(df):
    df = df.copy()
    df.columns = (
        df.columns.astype(str)
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
    )
    return df


def clean_data(df):
    df = standardize_columns(df)

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            "Missing required columns: " + ", ".join(missing)
        )

    df = df.dropna(subset=["customerid"]).copy()
    df["customerid"] = df["customerid"].astype(str).str.strip()
    df["invoiceno"] = df["invoiceno"].astype(str).str.strip()
    df["invoicedate"] = pd.to_datetime(df["invoicedate"], errors="coerce")
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
    df["unitprice"] = pd.to_numeric(df["unitprice"], errors="coerce")

    df = df.dropna(
        subset=["invoicedate", "quantity", "unitprice"]
    ).drop_duplicates()

    df = df[df["unitprice"] > 0]
    df = df[df["quantity"] != 0]

    # Remove returns/cancelled transactions, following the original project.
    df = df[df["quantity"] > 0].copy()

    df["total_amount"] = df["quantity"] * df["unitprice"]
    df = df[np.isfinite(df["total_amount"])]
    df = df[df["total_amount"] > 0].copy()

    if df.empty:
        raise ValueError("No valid transactions remain after cleaning.")

    return df


def build_rfm(df):
    reference_date = df["invoicedate"].max() + pd.Timedelta(days=1)

    customer_data = (
        df.groupby("customerid")
        .agg(
            Recency=("invoicedate", lambda x: (reference_date - x.max()).days),
            Frequency=("invoiceno", "nunique"),
            Monetary=("total_amount", "sum"),
        )
        .reset_index()
    )

    customer_data = customer_data[
        (customer_data["Recency"] >= 0)
        & (customer_data["Frequency"] > 0)
        & (customer_data["Monetary"] > 0)
    ].copy()

    if len(customer_data) < 3:
        raise ValueError("At least 3 valid customers are required for clustering.")

    return customer_data


def train_model(customer_data):
    rfm_data = customer_data[["Recency", "Frequency", "Monetary"]].copy()
    rfm_log = np.log1p(rfm_data)

    scaler = StandardScaler()
    rfm_scaled = scaler.fit_transform(rfm_log)

    max_k = min(10, len(customer_data) - 1)
    if max_k < 2:
        raise ValueError("Not enough customers to evaluate clusters.")

    cluster_range = list(range(2, max_k + 1))
    inertia_values = []
    silhouette_values = []

    for k in cluster_range:
        model = KMeans(n_clusters=k, random_state=42, n_init=20)
        labels = model.fit_predict(rfm_scaled)
        inertia_values.append(model.inertia_)
        silhouette_values.append(silhouette_score(rfm_scaled, labels))

    best_index = int(np.argmax(silhouette_values))
    best_k = cluster_range[best_index]
    best_silhouette = silhouette_values[best_index]

    kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=20)
    customer_data = customer_data.copy()
    customer_data["Cluster"] = kmeans.fit_predict(rfm_scaled)

    cluster_profile = (
        customer_data.groupby("Cluster")
        .agg(
            Customers=("customerid", "count"),
            Avg_Recency=("Recency", "mean"),
            Avg_Frequency=("Frequency", "mean"),
            Avg_Monetary=("Monetary", "mean"),
            Total_Revenue=("Monetary", "sum"),
        )
        .reset_index()
    )

    numeric_profile_cols = [
        "Avg_Recency", "Avg_Frequency", "Avg_Monetary", "Total_Revenue"
    ]
    cluster_profile[numeric_profile_cols] = cluster_profile[numeric_profile_cols].round(2)

    overall_recency = customer_data["Recency"].mean()
    overall_frequency = customer_data["Frequency"].mean()
    overall_monetary = customer_data["Monetary"].mean()

    cluster_profile["Recency_Ratio"] = (
        cluster_profile["Avg_Recency"] / overall_recency
    )
    cluster_profile["Frequency_Ratio"] = (
        cluster_profile["Avg_Frequency"] / overall_frequency
    )
    cluster_profile["Monetary_Ratio"] = (
        cluster_profile["Avg_Monetary"] / overall_monetary
    )

    def classify_segment(row):
        recency = row["Recency_Ratio"]
        frequency = row["Frequency_Ratio"]
        monetary = row["Monetary_Ratio"]

        if recency <= 0.75 and frequency >= 1.20 and monetary >= 1.20:
            return "High Value Customers"
        elif recency <= 0.85 and frequency >= 1.20:
            return "Loyal Customers"
        elif recency >= 1.30 and monetary >= 1.20:
            return "At Risk High-Value Customers"
        elif recency <= 0.85 and frequency < 0.80:
            return "New or Occasional Customers"
        elif recency >= 1.30 and frequency < 0.80 and monetary < 0.80:
            return "Low Engagement Customers"
        elif frequency >= 1.20 and monetary < 0.80:
            return "Frequent Low-Spend Customers"
        elif recency >= 1.50:
            return "Inactive Customers"
        else:
            return "Regular Customers"

    cluster_profile["Segment"] = cluster_profile.apply(
        classify_segment, axis=1
    )

    # Keep duplicate descriptive segment names distinguishable.
    counts = cluster_profile["Segment"].value_counts()
    duplicates = counts[counts > 1].index

    for segment in duplicates:
        mask = cluster_profile["Segment"] == segment
        cluster_profile.loc[mask, "Segment"] = (
            cluster_profile.loc[mask, "Segment"]
            + " (Cluster "
            + cluster_profile.loc[mask, "Cluster"].astype(str)
            + ")"
        )

    cluster_name_map = dict(
        zip(cluster_profile["Cluster"], cluster_profile["Segment"])
    )
    customer_data["Segment"] = customer_data["Cluster"].map(cluster_name_map)

    def get_strategy(segment):
        if "High Value" in segment:
            return "Use loyalty rewards, personalized recommendations, exclusive offers and early access to products."
        elif "Loyal" in segment:
            return "Use loyalty points, repeat-purchase rewards, cross-selling and personalized recommendations."
        elif "At Risk High-Value" in segment:
            return "Use re-engagement campaigns, personalized offers and reminders based on previous purchases."
        elif "New or Occasional" in segment:
            return "Use introductory offers, product recommendations and incentives to encourage repeat purchases."
        elif "Low Engagement" in segment:
            return "Use targeted promotions and low-cost re-engagement campaigns to increase customer activity."
        elif "Frequent Low-Spend" in segment:
            return "Use product bundles, cross-selling and volume-based offers to increase average spending."
        elif "Inactive" in segment:
            return "Use win-back campaigns, reminders and personalized offers to encourage another purchase."
        return "Use regular promotional campaigns, personalized recommendations and loyalty incentives."

    cluster_profile["Marketing_Strategy"] = cluster_profile["Segment"].apply(
        get_strategy
    )

    final_profile = cluster_profile[
        [
            "Cluster", "Segment", "Customers", "Avg_Recency",
            "Avg_Frequency", "Avg_Monetary", "Total_Revenue",
            "Marketing_Strategy"
        ]
    ].copy()

    return {
        "customer_data": customer_data,
        "cluster_profile": cluster_profile,
        "final_profile": final_profile,
        "scaler": scaler,
        "kmeans": kmeans,
        "cluster_name_map": cluster_name_map,
        "rfm_scaled": rfm_scaled,
        "cluster_range": cluster_range,
        "inertia_values": inertia_values,
        "silhouette_values": silhouette_values,
        "best_k": best_k,
        "best_silhouette": best_silhouette,
    }


def predict_segment(recency, frequency, monetary, artifacts):
    values = np.array([[recency, frequency, monetary]], dtype=float)
    values_log = np.log1p(values)
    values_scaled = artifacts["scaler"].transform(values_log)
    cluster = int(artifacts["kmeans"].predict(values_scaled)[0])
    return artifacts["cluster_name_map"][cluster]


def make_plots(artifacts):
    customer_data = artifacts["customer_data"]

    fig_dist, ax = plt.subplots(figsize=(9, 5))
    sns.histplot(customer_data["Monetary"], bins=40, kde=True, ax=ax)
    ax.set_title("Distribution of Customer Monetary Value")
    ax.set_xlabel("Monetary")
    ax.set_ylabel("Number of Customers")
    fig_dist.tight_layout()

    fig_elbow, ax = plt.subplots(figsize=(8, 5))
    ax.plot(
        artifacts["cluster_range"],
        artifacts["inertia_values"],
        marker="o"
    )
    ax.set_title("Elbow Method")
    ax.set_xlabel("Number of Clusters (K)")
    ax.set_ylabel("Within-Cluster Sum of Squares")
    ax.set_xticks(artifacts["cluster_range"])
    fig_elbow.tight_layout()

    fig_sil, ax = plt.subplots(figsize=(8, 5))
    ax.plot(
        artifacts["cluster_range"],
        artifacts["silhouette_values"],
        marker="o"
    )
    ax.set_title("Silhouette Scores")
    ax.set_xlabel("Number of Clusters (K)")
    ax.set_ylabel("Silhouette Score")
    ax.set_xticks(artifacts["cluster_range"])
    fig_sil.tight_layout()

    fig_segments, ax = plt.subplots(figsize=(10, 6))
    sns.scatterplot(
        data=customer_data,
        x="Frequency",
        y="Monetary",
        hue="Segment",
        s=80,
        ax=ax
    )
    ax.set_title("Customer Segmentation by Frequency and Monetary Value")
    ax.set_xlabel("Purchase Frequency")
    ax.set_ylabel("Total Spending")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
    fig_segments.tight_layout()

    pca = PCA(n_components=2)
    pca_result = pca.fit_transform(artifacts["rfm_scaled"])
    pca_df = pd.DataFrame(pca_result, columns=["PCA1", "PCA2"])
    pca_df["Segment"] = customer_data["Segment"].values

    fig_pca, ax = plt.subplots(figsize=(10, 6))
    sns.scatterplot(
        data=pca_df,
        x="PCA1",
        y="PCA2",
        hue="Segment",
        s=80,
        ax=ax
    )
    ax.set_title("Customer Segments Visualized Using PCA")
    ax.set_xlabel("Principal Component 1")
    ax.set_ylabel("Principal Component 2")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
    fig_pca.tight_layout()

    counts = customer_data["Segment"].value_counts()
    fig_size, ax = plt.subplots(figsize=(10, 5))
    counts.plot(kind="bar", ax=ax)
    ax.set_title("Number of Customers in Each Segment")
    ax.set_xlabel("Customer Segment")
    ax.set_ylabel("Number of Customers")
    ax.tick_params(axis="x", rotation=45)
    fig_size.tight_layout()

    return {
        "distribution": fig_dist,
        "elbow": fig_elbow,
        "silhouette": fig_sil,
        "segments": fig_segments,
        "pca": fig_pca,
        "sizes": fig_size,
    }


def dataframe_csv(df):
    return df.to_csv(index=False).encode("utf-8")


def excel_report(artifacts):
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        artifacts["customer_data"].to_excel(
            writer, sheet_name="Customer Segments", index=False
        )
        artifacts["final_profile"].to_excel(
            writer, sheet_name="Segment Profile", index=False
        )
    buffer.seek(0)
    return buffer.getvalue()


st.title("📊 Retail Customer Segmentation")
st.caption("RFM Analysis + K-Means Clustering + Customer Segment Prediction")

with st.sidebar:
    st.header("1. Upload Dataset")
    uploaded_file = st.file_uploader(
        "Upload your retail CSV file",
        type=["csv"]
    )

    st.markdown(
        """
**Required columns**
- `CustomerID`
- `InvoiceNo`
- `InvoiceDate`
- `Quantity`
- `UnitPrice`
"""
    )

if uploaded_file is None:
    st.info("Upload your retail CSV from the sidebar to start the analysis.")
    st.markdown(
        """
### What this app does
1. Cleans the transaction data.
2. Calculates customer-level **RFM** features.
3. Tests cluster counts from 2 to 10 (or the largest feasible range).
4. Selects K using the highest tested silhouette score.
5. Creates customer segments.
6. Shows marketing strategies for each segment.
7. Predicts a segment for a new customer.
8. Lets you download CSV and Excel results.
"""
    )
    st.stop()

try:
    raw_df = pd.read_csv(uploaded_file)
    cleaned_df = clean_data(raw_df)
    rfm_df = build_rfm(cleaned_df)
    artifacts = train_model(rfm_df)
except Exception as e:
    st.error(f"Could not process the dataset: {e}")
    st.stop()

plots = make_plots(artifacts)

st.success("Analysis completed successfully.")

col1, col2, col3, col4 = st.columns(4)
col1.metric("Transactions", f"{len(cleaned_df):,}")
col2.metric("Customers", f"{rfm_df['customerid'].nunique():,}")
col3.metric("Total Revenue", f"{cleaned_df['total_amount'].sum():,.2f}")
col4.metric(
    "Selected K",
    str(artifacts["best_k"]),
    f"Silhouette: {artifacts['best_silhouette']:.4f}"
)

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["Overview", "RFM Data", "Clusters", "Visualizations", "Prediction"]
)

with tab1:
    st.subheader("Dataset Preview")
    st.dataframe(cleaned_df.head(20), use_container_width=True)

    st.subheader("RFM Summary")
    st.dataframe(
        rfm_df[["Recency", "Frequency", "Monetary"]].describe().round(2),
        use_container_width=True
    )

with tab2:
    st.subheader("Customer-Level RFM Data")
    st.dataframe(
        artifacts["customer_data"].sort_values(
            "Monetary", ascending=False
        ),
        use_container_width=True
    )

    st.download_button(
        "⬇️ Download Customer Segments CSV",
        data=dataframe_csv(artifacts["customer_data"]),
        file_name="customer_segments.csv",
        mime="text/csv"
    )

with tab3:
    st.subheader("Cluster Profile")
    st.dataframe(
        artifacts["final_profile"],
        use_container_width=True
    )

    st.download_button(
        "⬇️ Download Segment Profile CSV",
        data=dataframe_csv(artifacts["final_profile"]),
        file_name="segment_profile.csv",
        mime="text/csv"
    )

    st.download_button(
        "⬇️ Download Excel Report",
        data=excel_report(artifacts),
        file_name="customer_segmentation_report.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

with tab4:
    st.subheader("Exploratory & Clustering Visualizations")

    c1, c2 = st.columns(2)
    with c1:
        st.pyplot(plots["distribution"])
        st.pyplot(plots["elbow"])
        st.pyplot(plots["silhouette"])
    with c2:
        st.pyplot(plots["segments"])
        st.pyplot(plots["pca"])
        st.pyplot(plots["sizes"])

with tab5:
    st.subheader("Predict Segment for a New Customer")
    st.write(
        "Enter the customer's RFM values. The same log transformation, "
        "scaler, and trained K-Means model used for the uploaded dataset "
        "will be applied."
    )

    c1, c2, c3 = st.columns(3)
    with c1:
        recency = st.number_input(
            "Recency (days)", min_value=0.0, value=20.0, step=1.0
        )
    with c2:
        frequency = st.number_input(
            "Frequency (orders)", min_value=1.0, value=15.0, step=1.0
        )
    with c3:
        monetary = st.number_input(
            "Monetary (total spending)", min_value=0.01, value=2500.0, step=100.0
        )

    if st.button("🔮 Predict Customer Segment", type="primary"):
        segment = predict_segment(
            recency, frequency, monetary, artifacts
        )
        st.success(f"Predicted Segment: **{segment}**")
